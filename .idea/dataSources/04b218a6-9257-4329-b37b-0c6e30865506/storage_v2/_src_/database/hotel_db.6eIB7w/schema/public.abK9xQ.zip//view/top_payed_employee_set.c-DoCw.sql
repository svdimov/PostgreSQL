create view top_payed_employee_set(id, first_name, last_name, job_title, department_id, salary) as
SELECT id,
       first_name,
       last_name,
       job_title,
       department_id,
       salary
FROM employees
ORDER BY salary DESC
LIMIT 1;

alter table top_payed_employee_set
    owner to postgres;

